﻿using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(BoxCollider2D))]
public class CharacterControllerScript : MonoBehaviour 
{
	private Rigidbody2D character;

	private Animator frame;

	private BoxCollider2D box;

	[SerializeField]
	private Vector2 _DeltaForce;

	public float maxSpeed = 4;

	void Awake() 
	{
		character = GetComponent<Rigidbody2D>();
		frame = GetComponent<Animator>();
		box = GetComponent<BoxCollider2D>();
	}
	void Start ()
	{
		character.gravityScale = 0;
		character.constraints=RigidbodyConstraints2D.FreezeRotation;
	}

	void Update () 
	{
		InputReader(frame);
	}

	void InputReader(Animator frame)
	{
		var Horizontal_ = Input.GetAxisRaw("Horizontal");
		var Vertical_ = Input.GetAxisRaw("Vertical");
		var run = Input.GetAxisRaw ("Jump");
		_DeltaForce = new Vector2(Horizontal_,Vertical_);
		if (run != 0) 
		{
			maxSpeed = 16;
		}
		else maxSpeed = 6;
		frame.SetFloat ("Horizontal", Horizontal_);
		frame.SetFloat ("Vertical", Vertical_);

		Simplify(_DeltaForce*maxSpeed);
	}
	void Simplify(Vector2 Impact)
	{
		character.velocity = Vector2.zero;
		character.AddForce(Impact,ForceMode2D.Impulse);
	}
}
