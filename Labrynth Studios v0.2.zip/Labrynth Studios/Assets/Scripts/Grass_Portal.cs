﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Grass_Portal : MonoBehaviour {
	
	[SerializeField] private string loadlevel;

	void OnTriggerEnter2D(Collider2D ChangeScene){
		if (ChangeScene.gameObject.CompareTag("Player")){
			SceneManager.LoadScene(loadlevel);
		}
	}
}
