﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class GameController : MonoBehaviour {
	public static GameController controller;
	public float health;
	public float position;

	void Awake () {
		if (controller == null) {
			DontDestroyOnLoad (gameObject);
			controller = this;
		} else if(controller != this){
			Destroy (gameObject);
		}
	}

	void OnGUI(){		//this can be deleted just for visualizing the persitent setting
		GUI.Label (new Rect (10, 10, 100, 30), "Health: " + health);
		GUI.Label (new Rect (10, 40, 100, 30), "Position: " + position);
		if(GUI.Button(new Rect(10, 60, 100, 30), "Increase Health")){
			GameController.controller.health += 10;
		}
	}

	public void save(){
		BinaryFormatter bf = new BinaryFormatter ();
		FileStream fs = File.Open (Application.persistentDataPath + "/playerInfo.dat", FileMode.Open);
		PlayerData data = new PlayerData ();
		data.health = health;
		data.position = position;

		bf.Serialize (fs, data);
		fs.Close ();
	}

	public void load(){
		if(File.Exists(Application.persistentDataPath+"/playerInfo.dat")){
			BinaryFormatter bf = new BinaryFormatter ();
			FileStream fs = File.Open (Application.persistentDataPath + "/playerInfo.dat", FileMode.Open);
			PlayerData data = (PlayerData)bf.Deserialize (fs);
			fs.Close ();

			health = data.health;
			position = data.position;
		}
	}
}

[Serializable]
class PlayerData{

	public float health;
	public float position;

}
