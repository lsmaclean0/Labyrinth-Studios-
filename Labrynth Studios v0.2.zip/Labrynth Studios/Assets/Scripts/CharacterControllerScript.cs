﻿using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(BoxCollider2D))]
public class CharacterControllerScript : MonoBehaviour 
{
	private Rigidbody2D character;
	private Animator frame;
	//private BoxCollider2D box;  idk what this was for
	public float dashSpeed;
	private float dashTime;
	public float startDashTime;
	private int Direction;

	[SerializeField]
	private Vector2 _DeltaForce;
	public float maxSpeed = 4;

	void Awake() 
	{
		character = GetComponent<Rigidbody2D>();
		frame = GetComponent<Animator>();
		//box = GetComponent<BoxCollider2D>(); idk what this was for
	}
	void Start ()
	{
		character.gravityScale = 0;
		character.constraints=RigidbodyConstraints2D.FreezeRotation;
	}

	void Update () 
	{
		InputReader(frame);
		Blink();
	}

	void InputReader(Animator frame)
	{
		var Horizontal_ = Input.GetAxisRaw("Horizontal");
		var Vertical_ = Input.GetAxisRaw("Vertical");
		//var run = Input.GetAxisRaw ("Jump");  //blink is on space right now, just a reminder to make running a thing
		_DeltaForce = new Vector2(Horizontal_,Vertical_);

		frame.SetFloat ("Horizontal", Horizontal_);
		frame.SetFloat ("Vertical", Vertical_);

		Simplify(_DeltaForce*maxSpeed);

	}

	void Simplify(Vector2 Impact)
	{
		character.velocity = Vector2.zero;
		character.AddForce(Impact,ForceMode2D.Impulse);
	}

	void Blink(){
		if (Input.GetKeyDown(KeyCode.Space)) {
			if (_DeltaForce.x.Equals (1)) {
				character.velocity = Vector2.right * dashSpeed;
			}else if (_DeltaForce.x.Equals (-1)) {
				character.velocity = Vector2.left * dashSpeed;
			}else if (_DeltaForce.y.Equals (1)) {
				character.velocity = Vector2.up * dashSpeed;
			}else if (_DeltaForce.y.Equals (-1)) {
				character.velocity = Vector2.down * dashSpeed;
			}

		}
	}
}
